#include "lecteurvue.h"
#include "ui_lecteurvue.h"
#include <QDebug>
#include <QAction>
LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{
    ui->setupUi(this);
    connect(ui->bLancer,SIGNAL(clicked()),this,SLOT(lancerDiaporama()));
    connect(ui->bArreter,SIGNAL(clicked()),this,SLOT(quitterDiaporama()));
    connect(ui->bPrecedent,SIGNAL(clicked()),this,SLOT(precedent()));
    connect(ui->bSuivant,SIGNAL(clicked()),this,SLOT(suivant()));
    connect(ui->actionEnlever_le_diaporama,SIGNAL(triggered()),this,SLOT(enleverDiaporama()));
    connect(ui->actionVitesse_de_defilement,SIGNAL(triggered()),this,SLOT(vitesseDefilement()));
    connect(ui->actionQuitter,SIGNAL(triggered()),this,SLOT(quitterFenetre()));
    connect(ui->actionA_propos_de,SIGNAL(triggered()),this,SLOT(aProposDe()));
    connect(ui->actionCharger_un_diaporama, SIGNAL(triggered()),this, SLOT(chargementDiaporama()));
    statusBar()->showMessage("Mode manuel");
}

LecteurVue::~LecteurVue()
{
    delete ui;
}

void LecteurVue::lancerDiaporama()
{
    qDebug()<<"lancement du diaporama";
    statusBar()->showMessage("Mode automatique");
    ui->bLancer->setEnabled(false);
}

void LecteurVue::quitterDiaporama()
{
    qDebug()<<"quitter le diaporama";
    statusBar()->showMessage("Mode manuel");
    ui->bLancer->setEnabled(true);
}

void LecteurVue::suivant()
{
    qDebug()<<"diapo suivante";
    ui->bLancer->setEnabled(true);
}

void LecteurVue::precedent()
{
    qDebug()<<"diapo précédente";
    ui->bLancer->setEnabled(true);
}

void LecteurVue::vitesseDefilement()
{
    qDebug()<<"changement de la vitesse";
}

void LecteurVue::enleverDiaporama()
{
    qDebug()<<"enlever le diaporama";
}

void LecteurVue::quitterFenetre()
{
    qDebug()<<"quitter la fenetre";
}

void LecteurVue::aProposDe()
{
    qDebug()<<"a propos de";
}

void LecteurVue::chargementDiaporama()
{
    qDebug() << "chargement du diaporama";
}
