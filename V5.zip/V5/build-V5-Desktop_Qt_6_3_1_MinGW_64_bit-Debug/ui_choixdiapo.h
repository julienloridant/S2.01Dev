/********************************************************************************
** Form generated from reading UI file 'choixdiapo.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHOIXDIAPO_H
#define UI_CHOIXDIAPO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ChoixDiapo
{
public:
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout;
    QLabel *label_2;
    QLabel *label_4;
    QPushButton *pushButton;
    QLabel *label_3;
    QLabel *label;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;

    void setupUi(QWidget *ChoixDiapo)
    {
        if (ChoixDiapo->objectName().isEmpty())
            ChoixDiapo->setObjectName(QString::fromUtf8("ChoixDiapo"));
        ChoixDiapo->resize(400, 300);
        horizontalLayout = new QHBoxLayout(ChoixDiapo);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_2 = new QLabel(ChoixDiapo);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 2, 1, 1, 1);

        label_4 = new QLabel(ChoixDiapo);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 0, 1, 1, 1);

        pushButton = new QPushButton(ChoixDiapo);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 0, 0, 1, 1);

        label_3 = new QLabel(ChoixDiapo);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 1, 1, 1, 1);

        label = new QLabel(ChoixDiapo);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 3, 1, 1, 1);

        pushButton_2 = new QPushButton(ChoixDiapo);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        gridLayout->addWidget(pushButton_2, 1, 0, 1, 1);

        pushButton_3 = new QPushButton(ChoixDiapo);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        gridLayout->addWidget(pushButton_3, 2, 0, 1, 1);

        pushButton_4 = new QPushButton(ChoixDiapo);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));

        gridLayout->addWidget(pushButton_4, 3, 0, 1, 1);


        verticalLayout->addLayout(gridLayout);

        pushButton_5 = new QPushButton(ChoixDiapo);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));

        verticalLayout->addWidget(pushButton_5);


        horizontalLayout->addLayout(verticalLayout);


        retranslateUi(ChoixDiapo);

        QMetaObject::connectSlotsByName(ChoixDiapo);
    } // setupUi

    void retranslateUi(QWidget *ChoixDiapo)
    {
        ChoixDiapo->setWindowTitle(QCoreApplication::translate("ChoixDiapo", "Form", nullptr));
        label_2->setText(QCoreApplication::translate("ChoixDiapo", "TextLabel", nullptr));
        label_4->setText(QCoreApplication::translate("ChoixDiapo", "Diapo de Yann ", nullptr));
        pushButton->setText(QCoreApplication::translate("ChoixDiapo", "S\303\251l\303\251ctionner", nullptr));
        label_3->setText(QCoreApplication::translate("ChoixDiapo", "Diapo de Thierry", nullptr));
        label->setText(QCoreApplication::translate("ChoixDiapo", "TextLabel", nullptr));
        pushButton_2->setText(QCoreApplication::translate("ChoixDiapo", "S\303\251lectionner", nullptr));
        pushButton_3->setText(QCoreApplication::translate("ChoixDiapo", "S\303\251lectionner", nullptr));
        pushButton_4->setText(QCoreApplication::translate("ChoixDiapo", "S\303\251l\303\251ctionner", nullptr));
        pushButton_5->setText(QCoreApplication::translate("ChoixDiapo", "PushButton", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ChoixDiapo: public Ui_ChoixDiapo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHOIXDIAPO_H
