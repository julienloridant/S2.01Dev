#include "lecteurvue.h"
#include "ui_lecteurvue.h"
#include "QSqlQuery"
#include <QDebug>
#include <QAction>
#include <QPixmap>
#include <QMessageBox>
#include <QString>
#include <QLineEdit>
#include <QInputDialog>
#include <QTimer>

LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{
    ui->setupUi(this);

    // Instanciation de la base de données
    db = new database();
    if (db->openDatabase())
    {
        qDebug() << "Base de données ouverte avec succès" << Qt::endl;
    }
    else
    {
        qDebug() << "Erreur à l'ouverture de la base de données" << Qt::endl;
    }

    connect(ui->bLancer,SIGNAL(clicked()),this,SLOT(lancerDiaporama()));
    connect(ui->bArreter,SIGNAL(clicked()),this,SLOT(arreterDiaporama()));
    connect(ui->bPrecedent,SIGNAL(clicked()),this,SLOT(precedent()));
    connect(ui->bSuivant,SIGNAL(clicked()),this,SLOT(suivant()));
    connect(ui->actionEnlever_le_diaporama,SIGNAL(triggered()),this,SLOT(enleverDiaporama()));
    connect(ui->actionVitesse_de_defilement,SIGNAL(triggered()),this,SLOT(vitesseDefilement()));
    connect(ui->actionQuitter,SIGNAL(triggered()),this,SLOT(quitterFenetre()));
    connect(ui->actionA_propos_de,SIGNAL(triggered()),this,SLOT(aProposDe()));
    connect(ui->actionCharger_un_diaporama, SIGNAL(triggered()),this, SLOT(chargementDiaporama()));
    statusBar()->showMessage("Mode manuel");
    _numDiaporamaCourant = 0;   // =  le lecteur est vide

    //Mode Automatique utile à partir de la V3
    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(suivantAuto()));
    ui->bArreter->setEnabled(false);



}

int vitesse = 1000;

LecteurVue::~LecteurVue()
{
    delete ui;
}

//Methodes LecteurVue V1
void LecteurVue::lancerDiaporama()
{
    _posImageCourante = 0;
    timer->start(2000);
    qDebug()<<"lancement du diaporama";
    statusBar()->showMessage("Mode automatique");
    ui->bLancer->setEnabled(false);
    ui->bArreter->setEnabled(true);

}

void LecteurVue::arreterDiaporama()
{
    qDebug()<<"arreter le diaporama";
    statusBar()->showMessage("Mode manuel");
    ui->bLancer->setEnabled(true);
    ui->bArreter->setEnabled(false);
    arreterModeAutomatique();
}

void LecteurVue::suivant()
{
    qDebug()<<"diapo suivante";
    avancer();
    afficher();
    arreterModeAutomatique();
    statusBar()->showMessage("Mode manuel");
    ui->bLancer->setEnabled(true);
}

void LecteurVue::precedent()
{
    qDebug()<<"diapo précédente";
    reculer();
    afficher();
    arreterModeAutomatique();
    statusBar()->showMessage("Mode manuel");
    ui->bLancer->setEnabled(true);
}

//Méthode permettant au mode automatique de passer à l'image suivante utile à partir de la V3
void LecteurVue::suivantAuto()
{
    qDebug()<<"diapo suivante";
    avancer();
    afficher();
}
//Méthode permettant de modifier la vitesse de défilement des images utile à partir de la V4
void LecteurVue::vitesseDefilement()
{
    qDebug()<<"changement de la vitesse";
    timer->stop();
    //creation de la fenetre de dialogue
    bool* ok;
    QString tempsSaisie = QInputDialog::getText(this,"vitesse de défilement ","Veuillez saisir la nouvelle vitesse en seconde :",QLineEdit::Normal,QString(),ok);
    int vitesse =  tempsSaisie.toInt() *1000;//conversion des secondes en millisecondes
    if (ok and !(tempsSaisie.isEmpty()) ){
        timer->start(vitesse);
        statusBar()->showMessage("Mode Automatique");

    }
    else{
        qDebug()<<"la vitesse n'a pas été changée";
    }

}

void LecteurVue::enleverDiaporama()
{
    qDebug()<<"enlever le diaporama";
    viderDiaporama();
}

void LecteurVue::quitterFenetre()
{
    qDebug()<<"quitter la fenetre";
    close();
}

void LecteurVue::aProposDe()
{
    qDebug()<<"a propos de";
    QMessageBox::information(this,"À propos de l'application","Version : 5.0\n Auteurs : MORANCE Kyllian, LORIDANT Julien, VERNIS Gabriel \n Date de création : 16/05/2023");
}

void LecteurVue::chargementDiaporama()
{
    qDebug() << "chargement du diaporama";
    chargerDiaporama();
}

//Méthodes Lecteur V0
void LecteurVue::avancer()
{

    if (_posImageCourante >= nbImages()-1)
    {
        _posImageCourante = 0;
    }

    else if (nbImages() > 0)
    {
        _posImageCourante = _posImageCourante + 1;
    }
}

void LecteurVue::reculer()
{
    if (_posImageCourante <= 0)
    {
        _posImageCourante = nbImages()-1;
    }

    else
    {
        _posImageCourante = _posImageCourante - 1;
    }
}

void LecteurVue::changerDiaporama(unsigned int pNumDiaporama)
{
    // s'il y a un diaporama courant, le vider, puis charger le nouveau Diaporama

    if (numDiaporamaCourant() > 0)
    {
        viderDiaporama();
    }
    _numDiaporamaCourant = pNumDiaporama;
    if (numDiaporamaCourant() > 0)
    {
        chargerDiaporama(); // charge le diaporama courant
    }

}


Image::Image(unsigned int pRang, string pCategorie, string pTitre, string pChemin)
{

    _rang = pRang;
    _categorie = pCategorie;
    _titre = pTitre;
    _chemin = pChemin;

}

void LecteurVue::chargerDiaporama()
{
    /* Chargement des images associées au diaporama courant
       Dans une version ultérieure, ces données proviendront d'une base de données,
       et correspondront au diaporama choisi */
    Image *imageACharger;
    QSqlQuery requeteChargementDiaporama;
    requeteChargementDiaporama.exec("SELECT DiaposDansDiaporama.rang, Diapos.titrePhoto, Familles.nomFamille, Diapos.uriPhoto, Diaporamas.idDiaporama FROM Diaporamas JOIN DiaposDansDiaporama ON Diaporamas.idDiaporama=DiaposDansDiaporama.idDiaporama JOIN Diapos ON DiaposDansDiaporama.idDiapo=Diapos.idphoto JOIN Familles ON Diapos.idFam = Familles.idFamille WHERE Diaporamas.idDiaporama='4' ORDER BY DiaposDansDiaporama.rang");


    for(int i=0; requeteChargementDiaporama.next();i++)
    {
        qDebug() << requeteChargementDiaporama.value(0) << requeteChargementDiaporama.value(1) << requeteChargementDiaporama.value(2) << requeteChargementDiaporama.value(3) << Qt::endl;
        int rang = requeteChargementDiaporama.value(0).toInt();
        QString categorieAConvertir = requeteChargementDiaporama.value(2).toString();
        QString titreAConvertir = requeteChargementDiaporama.value(1).toString();
        QString cheminAConvertir = requeteChargementDiaporama.value(3).toString();
        int numDiapo = requeteChargementDiaporama.value(4).toInt();

        string categorie = categorieAConvertir.toStdString();
        string titre = titreAConvertir.toStdString();
        string chemin = cheminAConvertir.toStdString();
        imageACharger = new Image(rang,categorie,titre,chemin);
        _diaporama.push_back(imageACharger);
        _numDiaporamaCourant = numDiapo;
    }

    //Nous avons décidé de ne plus utilisé le tri car nous trions les images avec la requête ORDER BY
    /*
    // trier le contenu du diaporama par ordre croissant selon le rang de l'image dans le diaporama
    Image* imageATrier;
    for (unsigned int i = 0; i < nbImages()-1; i++) {
        for (unsigned int j = 0; j < nbImages()-i-1; j++) {
            if (_diaporama[j]->getRang() > _diaporama[j+1]->getRang()){
                imageATrier = _diaporama[j];
                _diaporama[j]=_diaporama[j+1];
                _diaporama[j+1]=imageATrier;
            }
        }
    }
    */
    _posImageCourante = 0;

    cout << "Diaporama num. " << numDiaporamaCourant() << " selectionne. " << endl;
    cout << nbImages() << " images chargees dans le diaporama" << endl;
}

void LecteurVue::viderDiaporama()
{
    if (nbImages () > 0)
    {
        unsigned int taille = nbImages();
        for (unsigned int i = 0; i < taille ; i++)
        {
            _diaporama.pop_back(); /* Removes the last element in the vector,
                                      effectively reducing the container size by one.
                                      AND deletes the removed element */
        }
        _posImageCourante = 0;
        _numDiaporamaCourant = 0;
    }
    cout << nbImages() << " images restantes dans le diaporama." << endl;

}

void LecteurVue::afficher()
{
    /* affiche les information sur le lecteur :
     * 1) vide (si num. de diaporama = 0) OU BIEN  numéro de diaporama affiché
     * 2) Si un diaporama courant est chargé (num. de diaporama > 0), affiche l'image courante OU BIEN 'diaporama vide'
     *     si ce diaporama n'a aucun image */
    if (numDiaporamaCourant() == 0)
    {
        cout << "Lecteur vide" << endl;
    }
    else
    {
        cout <<"Diaporama num." <<numDiaporamaCourant() << endl;

        if(numDiaporamaCourant() > 0)
        {

            cout << "image courante : ";
            _diaporama[_posImageCourante]->Image::afficher();
            //Affichage V2
            //Affichage Titre de l'image
            ui->lTitre->setText(QString::fromStdString(imageCourante()->getTitre()));

            //Affichage de la catégorie de l'image
            ui->lCategorie->setText(QString::fromStdString(imageCourante()->getCategorie()));

            //Affichage de l'image
            ui->lImage->setPixmap(QPixmap(":"+QString::fromStdString(imageCourante()->getChemin())));
        }
        else
        {
            cout << "diaporama vide";
        }
    }
}

unsigned int LecteurVue::nbImages()
{
    return _diaporama.size();
}

Image *LecteurVue::imageCourante()
{
    if (nbImages()==0)
    {
        return nullptr ;
    }

    else
    {
        return _diaporama[_posImageCourante];
    }
}

unsigned int LecteurVue::numDiaporamaCourant()
{
    return _numDiaporamaCourant;
}

void LecteurVue::arreterModeAutomatique()
{
    timer->stop();
    afficher();
}
