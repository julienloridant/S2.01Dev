#include "diaporama.h"
#include "database.h"

Diaporama::Diaporama()
{

}

//setters
void Diaporama::setTitre(QChar c){
    (*this)._titre = c;
}

void Diaporama::setVitesse(int v){
    (*this)._vitesse = v;
}


//getters
int Diaporama::getVitesse(){
    return (*this)._vitesse;
}

char Diaporama::getTitre(){
    return (*this)._titre;
}











