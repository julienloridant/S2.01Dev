
#ifndef CHOIXDIAPO_H
#define CHOIXDIAPO_H

#include <QDialog>
#include <QSqlQuery>

namespace Ui {
class ChoixDiapo;
}

class ChoixDiapo : public QDialog
{
    Q_OBJECT

public:
    explicit ChoixDiapo(QWidget *parent = nullptr);
    ~ChoixDiapo();

    bool EtatFenetre;
    void setEtatFenetre(bool etat);
    bool getEtatFenetre();
    int getChoixDiapo();

private:
    Ui::ChoixDiapo *ui;
    int choixDiapo;
public slots:
    void confirmerChoixDiapo();
    void annulerChoixDiapo();

};

#endif // CHOIXDIAPO_H

