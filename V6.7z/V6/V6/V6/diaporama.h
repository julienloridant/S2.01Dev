#ifndef DIAPORAMA_H
#define DIAPORAMA_H
#include <QObject>
#include <QChar>

class Diaporama
{

private:

    int _vitesse;
    char _titre;






public:
    Diaporama();
    ~Diaporama();
    char getTitre();
    int getVitesse();
    void setTitre(Qchar);
    void setVitesse(int);

};

#endif // DIAPORAMA_H
