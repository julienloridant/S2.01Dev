#include "choixdiapo.h"
#include "ui_choixdiapo.h"
#include "diaporama.h"


ChoixDiapo::ChoixDiapo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ChoixDiapo)
{
    ui->setupUi(this);
    connect(ui->bValider,SIGNAL(clicked()),this,SLOT(confirmerChoixDiapo()));
    connect(ui->bAnnuler,SIGNAL(clicked()),this,SLOT(annulerChoixDiapo()));

    QSqlQuery requeteDiapo;
    requeteDiapo.exec("SELECT idDiaporama, `titre Diaporama` FROM `Diaporamas`");

    int numDiapoMin = requeteDiapo.value(0).toInt();
    int numDiapoMax = 0;

    //Remplissage du tableau
    for (int i=0; requeteDiapo.next();i++)
    {
        qDebug()<< requeteDiapo.value(0) << requeteDiapo.value(1) << Qt::endl;
        numDiapoMin = requeteDiapo.value(0).toInt() - i;
        if (numDiapoMax < requeteDiapo.value(0).toInt())
        {
            numDiapoMax = requeteDiapo.value(0).toInt();
        }
        ui->tabDiapo->insertRow(i);
        ui->tabDiapo->setItem(i,0,new QTableWidgetItem(requeteDiapo.value(0).toString()));
        ui->tabDiapo->setItem(i,1,new QTableWidgetItem(requeteDiapo.value(1).toString()));
    }

    // Choix du diapo
    ui->sSelection->setMinimum(numDiapoMin);
    ui->sSelection->setMaximum(numDiapoMax);
}

ChoixDiapo::~ChoixDiapo()
{
    delete ui;
}

void ChoixDiapo::confirmerChoixDiapo()
{
    bool confirmationChoix = true;
    setEtatFenetre(confirmationChoix);
    close();
}

void ChoixDiapo::annulerChoixDiapo()
{
    bool annulationChoix =  false;
    setEtatFenetre(annulationChoix);
    close();
}

void ChoixDiapo::setEtatFenetre(bool etat)
{
    EtatFenetre = etat;
}

bool ChoixDiapo::getEtatFenetre()
{
    return EtatFenetre;
}
int ChoixDiapo::getChoixDiapo()
{
    int choixDiapo = ui->sSelection->value();
    return choixDiapo;
}

