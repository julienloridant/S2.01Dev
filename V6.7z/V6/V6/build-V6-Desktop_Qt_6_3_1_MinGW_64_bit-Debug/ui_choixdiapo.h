/********************************************************************************
** Form generated from reading UI file 'choixdiapo.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHOIXDIAPO_H
#define UI_CHOIXDIAPO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ChoixDiapo
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *lTitre;
    QTableWidget *tabDiapo;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer;
    QSpinBox *sSelection;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout;
    QPushButton *bValider;
    QPushButton *bAnnuler;

    void setupUi(QDialog *ChoixDiapo)
    {
        if (ChoixDiapo->objectName().isEmpty())
            ChoixDiapo->setObjectName(QString::fromUtf8("ChoixDiapo"));
        ChoixDiapo->resize(400, 300);
        verticalLayout_2 = new QVBoxLayout(ChoixDiapo);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        lTitre = new QLabel(ChoixDiapo);
        lTitre->setObjectName(QString::fromUtf8("lTitre"));
        QFont font;
        font.setPointSize(15);
        font.setBold(true);
        lTitre->setFont(font);
        lTitre->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(lTitre);

        tabDiapo = new QTableWidget(ChoixDiapo);
        if (tabDiapo->columnCount() < 2)
            tabDiapo->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tabDiapo->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QFont font1;
        font1.setPointSize(9);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        __qtablewidgetitem1->setFont(font1);
        tabDiapo->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        tabDiapo->setObjectName(QString::fromUtf8("tabDiapo"));

        verticalLayout->addWidget(tabDiapo);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        sSelection = new QSpinBox(ChoixDiapo);
        sSelection->setObjectName(QString::fromUtf8("sSelection"));

        horizontalLayout_3->addWidget(sSelection);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        bValider = new QPushButton(ChoixDiapo);
        bValider->setObjectName(QString::fromUtf8("bValider"));

        horizontalLayout->addWidget(bValider);

        bAnnuler = new QPushButton(ChoixDiapo);
        bAnnuler->setObjectName(QString::fromUtf8("bAnnuler"));

        horizontalLayout->addWidget(bAnnuler);


        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(ChoixDiapo);

        QMetaObject::connectSlotsByName(ChoixDiapo);
    } // setupUi

    void retranslateUi(QDialog *ChoixDiapo)
    {
        ChoixDiapo->setWindowTitle(QCoreApplication::translate("ChoixDiapo", "Dialog", nullptr));
        lTitre->setText(QCoreApplication::translate("ChoixDiapo", "S\303\251lection du diaporama \303\240 charger", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tabDiapo->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("ChoixDiapo", "idDiaporama", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tabDiapo->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("ChoixDiapo", "titre Diaporama", nullptr));
        bValider->setText(QCoreApplication::translate("ChoixDiapo", "Valider choix", nullptr));
        bAnnuler->setText(QCoreApplication::translate("ChoixDiapo", "Annuler choix", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ChoixDiapo: public Ui_ChoixDiapo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHOIXDIAPO_H
